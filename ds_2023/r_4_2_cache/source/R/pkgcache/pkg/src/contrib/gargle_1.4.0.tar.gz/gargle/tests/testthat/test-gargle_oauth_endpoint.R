test_that("gargle_oauth_endpoint() snapshot", {
  expect_snapshot(gargle_oauth_endpoint())
})
