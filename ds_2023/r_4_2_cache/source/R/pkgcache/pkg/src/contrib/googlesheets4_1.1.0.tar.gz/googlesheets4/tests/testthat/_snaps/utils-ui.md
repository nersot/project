# abort_unsupported_conversion() works

    Don't know how to make an instance of <target_class> from something of class <a/b/c>.

